import Dashboard from "layouts/Dashboard/Dashboard.jsx";
import ShowMemory from "views/ShowMemory/ShowMemory";

const indexRoutes = [{ path: "/", component: Dashboard }];

export default indexRoutes;
