var Constants = {
  // API: 'http://localhost:1337'
  // API: 'http://52.7.87.173:5000/swagger-ui.html#' -> Previous
  API: 'http://52.7.87.173:8080'
}
export default Constants
